# 🦆 老鸭版 · 快手抓鸭子 V4 — 原 APK 保留增强工程

## 与此前 V3 的关键区别

**V4 从用户上传的 `base(3).apk` 直接重新封装**。使用 Apktool `--no-src` 保留原版 `classes.dex` 的每个字节，原版本有的界面类和游戏逻辑均保留，通过新编译的 `classes2.dex` 扩展多账号控制台。

两个入口：启动默认进入 V4 管理页面；点击“原版界面 ↗”可进入原包 `com.chengfeng.duckassist.MainActivity` 进行原版操作。批量执行界面调用同一 APK 内的原版 `DuckClient`，不再运行时复制、加载第二套原版 DEX。

## 功能

- 保留原 APK 原来的 Activity、DuckClient 游戏执行方法、联网参数、资源及图标，提供原版界面直达入口。
- 账号批量导入、完整参数保存、可编辑备注、UID 去重、选择多个账号执行、按账号记录日志、结果、续接局次。
- 目标蛋数、次数上限、任务间隔、顺序/双并发、停止/暂停队列。
- 本地 AES-GCM 加密、相册自定义头像、账号 JSON 导入导出备份。
- 安装包使用新包名 `com.chengfeng.duckassist.laoya`，以便原 APK 与 V4 并排安装，不覆盖原版数据。

## GitHub Actions 编译

1. 在**私有仓库**上传整个工程，确保根目录存在 `original/base.apk`, `app`, `scripts`, `.github`。不要上传账号数据或 CK。
2. GitHub Actions → **Build Original APK Enhanced V4** → Run workflow。
3. 构建成功后从 Artifacts 下载 `LaoYaDuckV4-OriginalPreserved-APK`，解压安装 `老鸭版-快手抓鸭子V4.apk`。

**签名**：第一次测试若没配 Secrets，工作流生成临时签名。此时每次编译都不能直接覆盖安装，必须先做账号备份。若需要后续平滑升级，请提前配置仓库 Secrets `ANDROID_KEYSTORE_BASE64`、`ANDROID_KEYSTORE_PASSWORD`、`ANDROID_KEY_ALIAS`（以及可选的 `ANDROID_KEY_PASSWORD`）。

## 验证与限制

- `python3 scripts/verify_source.py`, `node docs/test_parser.js`, `node docs/test_original_bridge.js` 用于源代码和队列模拟测试；必须到 GitHub Runner 完成 Android 编译。
- 构建脚本验证原版 DEX SHA256 一致、classes2.dex 存在、APK 签名通过。
- 本地环境没有 Android SDK，**暂未编译或真机验证**。不能将源代码检查冒充 Android 真机成功。
- 新版和原版是两个独立的应用，原版保存的账号不能自动读取，要在 V4 中重新导入。
- 原包网络接口是否仍可用由服务端决定；使用自己账号并遵守平台规则。

原 APK SHA256: `205f34cb1d8907c34770214ae36b305ff2b0b15dff72b2dd7cbc41356350734f`  
原始 classes.dex SHA256: `3e671e0c80564ffe3ddd8a534fe71a9e2c7b97c891c5335a2da470cbc1e4358f`
