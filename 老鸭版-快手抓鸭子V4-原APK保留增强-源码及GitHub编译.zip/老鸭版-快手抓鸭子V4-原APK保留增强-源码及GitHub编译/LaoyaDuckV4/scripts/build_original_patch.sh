#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
APKTOOL_JAR="$ROOT/.tools/apktool_3.0.3.jar"
mkdir -p "$ROOT/.tools" "$ROOT/rebuilt"
if [[ ! -f "$APKTOOL_JAR" ]];then
 curl --retry 3 -L --fail --silent --show-error \
   'https://github.com/iBotPeaches/Apktool/releases/download/v3.0.3/apktool_3.0.3.jar' \
   -o "$APKTOOL_JAR"
fi
echo "dbf930b076c6b9be08d57c449cacefc3bdd6b71ebd59b3066fc0e1f5b14f9423  $APKTOOL_JAR" | sha256sum -c -
# A separate Android Gradle build compiles *only supplemental V4 activity code*.
gradle :app:assembleDebug --no-daemon --stacktrace
SUPPORT="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -s "$SUPPORT"
python3 - <<'PY_V4_CHECK_PRE'
import hashlib,zipfile
with zipfile.ZipFile('original/base.apk') as original, zipfile.ZipFile('app/build/outputs/apk/debug/app-debug.apk') as supplement:
 d=original.read('classes.dex'); s=supplement.read('classes.dex')
 assert b'com/chengfeng/duckassist' in d, 'Incorrect original DEX'
 assert b'com/laoya/duckv2' in s, 'Supplemental V4 DEX missing'
 assert len(d)>30000 and len(s)>10000
 print('Original dex SHA-256:',hashlib.sha256(d).hexdigest())
 print('Supplemental dex SHA-256:',hashlib.sha256(s).hexdigest())
PY_V4_CHECK_PRE
# --no-src preserves original classes.dex; no disassembly or edits to its functions.
java -jar "$APKTOOL_JAR" decode --force --no-src original/base.apk -o rebuilt/apktool_decoded
python3 scripts/patch_original.py rebuilt/apktool_decoded
mkdir -p rebuilt/apktool_decoded/assets
cp app/src/main/assets/index.html app/src/main/assets/app.js app/src/main/assets/style.css rebuilt/apktool_decoded/assets/
java -jar "$APKTOOL_JAR" build rebuilt/apktool_decoded -o rebuilt/unsigned.apk
python3 - <<'PY_V4_MERGE'
import zipfile,os,hashlib
src='rebuilt/unsigned.apk'; tmp='rebuilt/unsigned-v4.apk'
with zipfile.ZipFile('app/build/outputs/apk/debug/app-debug.apk') as sp:
 supplement=sp.read('classes.dex')
with zipfile.ZipFile('original/base.apk') as orig:
 core=orig.read('classes.dex')
with zipfile.ZipFile(src) as old,zipfile.ZipFile(tmp,'w') as out:
 found_core=False
 for entry in old.infolist():
  if entry.filename=='classes2.dex' or entry.filename.startswith('META-INF/'):
   continue
  if entry.filename=='classes.dex':
   out.writestr(entry,core)
   found_core=True
  else:
   out.writestr(entry,old.read(entry.filename))
 if not found_core:
  out.writestr('classes.dex',core,compress_type=zipfile.ZIP_DEFLATED)
 out.writestr('classes2.dex',supplement,compress_type=zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(tmp) as new:
 assert new.read('classes.dex')==core
 assert len(new.read('classes2.dex'))>10000
 assert all(x in new.namelist() for x in ['assets/index.html','assets/app.js','assets/style.css'])
os.replace(tmp,src)
print('Unmodified original DEX retained:',hashlib.sha256(core).hexdigest())
PY_V4_MERGE
BUILD_TOOLS="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/opt/android-sdk}}/build-tools/35.0.0"
test -x "$BUILD_TOOLS/zipalign"
test -x "$BUILD_TOOLS/apksigner"
"$BUILD_TOOLS/zipalign" -f -p 4 rebuilt/unsigned.apk rebuilt/aligned.apk
if [[ -n "${ANDROID_KEYSTORE_BASE64:-}" ]];then
 printf '%s' "$ANDROID_KEYSTORE_BASE64" | base64 --decode > rebuilt/private-keystore.jks
 KEYSTORE_PASS="${ANDROID_KEYSTORE_PASSWORD:?Missing ANDROID_KEYSTORE_PASSWORD secret}"
 KEY_ALIAS="${ANDROID_KEY_ALIAS:-laoyav4}"
else
 echo 'WARNING: An ephemeral signing key will require reinstalling for future builds.'
 KEYSTORE_PASS='laoya-v4-ephemeral'
 KEY_ALIAS='laoyav4'
 keytool -genkeypair -noprompt -keystore rebuilt/private-keystore.jks -alias "$KEY_ALIAS" \
  -storepass "$KEYSTORE_PASS" -keypass "$KEYSTORE_PASS" -keyalg RSA -keysize 3072 \
  -validity 3650 -dname 'CN=LaoYa V4 Debug, OU=Personal, O=LaoYa, L=Local, ST=Local, C=CN'
fi
"$BUILD_TOOLS/apksigner" sign --ks rebuilt/private-keystore.jks --ks-key-alias "$KEY_ALIAS" \
 --ks-pass "pass:$KEYSTORE_PASS" --key-pass "pass:${ANDROID_KEY_PASSWORD:-$KEYSTORE_PASS}" \
 --out 'rebuilt/老鸭版-快手抓鸭子V4.apk' rebuilt/aligned.apk
"$BUILD_TOOLS/apksigner" verify --verbose 'rebuilt/老鸭版-快手抓鸭子V4.apk'
"$BUILD_TOOLS/aapt" dump badging 'rebuilt/老鸭版-快手抓鸭子V4.apk' | head -15
python3 - <<'PY_V4_FINAL'
import zipfile,hashlib
path='rebuilt/老鸭版-快手抓鸭子V4.apk'
with zipfile.ZipFile(path) as z, zipfile.ZipFile('original/base.apk') as orig:
 assert z.read('classes.dex')==orig.read('classes.dex'), 'Original classes.dex was changed'
 assert 'classes2.dex' in z.namelist(), 'V4 activity dex was not packaged'
 print('Final signed APK sha256:',hashlib.sha256(open(path,'rb').read()).hexdigest())
PY_V4_FINAL
rm -f rebuilt/private-keystore.jks
