#!/usr/bin/env python3
"""Modify only decoded AndroidManifest; keep original smali/DEX untouched.
GitHub Actions combines original classes.dex + newly compiled supplemental classes2.dex.
"""
import pathlib,sys,xml.etree.ElementTree as ET
if len(sys.argv)!=2:raise SystemExit('Usage: patch_original.py <apktool-decoded-directory>')
root=pathlib.Path(sys.argv[1]);path=root/'AndroidManifest.xml'
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
a='{http://schemas.android.com/apk/res/android}'
tree=ET.parse(path);manifest=tree.getroot();oldpackage=manifest.get('package')
print('Original package:',oldpackage)
assert oldpackage=='com.chengfeng.duckassist', f'Unrecognized original package: {oldpackage}'
app=manifest.find('application');assert app is not None
original=None
for activity in app.findall('activity'):
 name=activity.get(a+'name','')
 if name in ('.MainActivity','com.chengfeng.duckassist.MainActivity'):
  original=activity;break
assert original is not None, 'Original MainActivity missing; refuse destructive patch'
for filt in list(original.findall('intent-filter')):
 actions=[e.get(a+'name') for e in filt.findall('action')]
 if 'android.intent.action.MAIN' in actions:
  original.remove(filt)
original.set(a+'name','com.chengfeng.duckassist.MainActivity')
original.set(a+'exported','false')
# Clone application id avoids signing conflict and data loss when original remains installed.
manifest.set('package','com.chengfeng.duckassist.laoya')
app.set(a+'label','老鸭版 · 快手抓鸭子 V4')
app.set(a+'allowBackup','false')
new=ET.SubElement(app,'activity',{
 a+'name':'com.laoya.duckv2.MainActivity',
 a+'exported':'true',
 a+'windowSoftInputMode':'adjustResize',
 a+'theme':'@android:style/Theme.Material.Light.NoActionBar',
})
filt=ET.SubElement(new,'intent-filter')
ET.SubElement(filt,'action',{a+'name':'android.intent.action.MAIN'})
ET.SubElement(filt,'category',{a+'name':'android.intent.category.LAUNCHER'})
if manifest.find('uses-permission[@'+a+'name="android.permission.INTERNET"]') is None:
 ET.SubElement(manifest,'uses-permission',{a+'name':'android.permission.INTERNET'})
# 4.0: only the package/launcher are modified; original Activity still exists and still runs.
tree.write(path,encoding='utf-8',xml_declaration=True)
print('Added new launcher; original Activity preserved; new package side-by-side.')
