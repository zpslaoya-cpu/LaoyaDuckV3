#!/usr/bin/env python3
import pathlib,zipfile,hashlib
base=pathlib.Path(__file__).resolve().parent.parent
with zipfile.ZipFile(base/'original/base.apk') as z:
 core=z.read('classes.dex')
 assert len(core)>30000
 for name in ['AndroidManifest.xml','resources.arsc','META-INF/DUCKASSI.RSA']:
  assert name in z.namelist()
print('original dex bytes:',len(core),'sha256',hashlib.sha256(core).hexdigest())
bridge=(base/'app/src/main/java/com/laoya/duckv2/OriginalDuckEngine.java').read_text()
assert 'getClassLoader()' in bridge and 'DexClassLoader' not in bridge
assert 'farm.invoke(' in bridge and 'probeHost.invoke(' in bridge
native=(base/'app/src/main/java/com/laoya/duckv2/MainActivity.java').read_text()
assert 'openOriginalApp()' in native and 'com.chengfeng.duckassist.MainActivity' in native
web=(base/'app/src/main/assets/app.js').read_text()
for feature in ['parseImport','importAccounts','startBatch','stopBatch','togglePause','openOriginal']:
 assert feature in web
print('source assertions PASSED')
