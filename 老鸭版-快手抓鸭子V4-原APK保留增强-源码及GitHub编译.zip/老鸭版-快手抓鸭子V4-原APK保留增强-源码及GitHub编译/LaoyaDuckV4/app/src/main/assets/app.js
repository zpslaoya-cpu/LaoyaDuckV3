(() => {'use strict';
const $=id=>document.getElementById(id), native=!!window.DuckNative;
const KEYS={data:'laoya_duck_v4_data',avatar:'laoya_duck_v4_avatar'};
const state={accounts:[],selection:[],logs:[],avatar:'',mask:true,running:false,stopped:false,paused:false,success:0,error:0,queue:[],jobMap:new Map(),pending:new Map(),seq:0};
const escapeHtml=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function id(){return 'a'+Date.now().toString(36)+Math.random().toString(36).slice(2,9)}
function toast(msg){$('toast').textContent=msg;$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,2600)}
function log(msg,kind='info'){const time=new Date().toLocaleTimeString('zh-CN',{hour12:false});state.logs.push({time,msg:String(msg),kind});if(state.logs.length>600)state.logs.shift();renderLogs()}
function readStorage(){try{const str=native?window.DuckNative.loadData():(localStorage.getItem(KEYS.data)||localStorage.getItem('laoya_duck_v3_data')||localStorage.getItem('laoya_duck_v2_data'));if(str){const obj=JSON.parse(str);state.accounts=Array.isArray(obj.accounts)?obj.accounts.filter(a=>a&&typeof a.param==='string').map(a=>({id:String(a.id||id()),note:String(a.note||'未命名'),param:String(a.param),enabled:a.enabled!==false,status:'',lastResult:'',rid:String(a.rid||'')})):[];state.selection=Array.isArray(obj.selection)?obj.selection:[];state.mask=obj.mask!==false;}if(native){state.avatar=window.DuckNative.loadAvatar()||''}else state.avatar=localStorage.getItem(KEYS.avatar)||localStorage.getItem('laoya_duck_v3_avatar')||localStorage.getItem('laoya_duck_v2_avatar')||'';}catch(e){log('读取配置失败：'+e.message,'error')}}
function save(){const obj={schema:2,updatedAt:new Date().toISOString(),accounts:state.accounts.map(({id,note,param,enabled,rid})=>({id,note,param,enabled,rid})),selection:state.selection,mask:state.mask};try{const serialized=JSON.stringify(obj);if(native){window.DuckNative.saveData(serialized)}else localStorage.setItem(KEYS.data,serialized);$('footerInfo').textContent='已保存 '+new Date().toLocaleTimeString('zh-CN',{hour12:false});return true}catch(e){toast('保存失败：存储空间可能已满');log('保存失败：'+e.message,'error');return false}}
function updateAvatar(){const img=$('avatar');img.hidden=!state.avatar;if(state.avatar)img.src=state.avatar;$('avatarFallback').hidden=!!state.avatar}
function uidOf(s){let m=String(s).match(/(?:^|;)\s*(?:ud|userId|userid)\s*=\s*([^;]+)/i);return m?m[1].trim():''}
function uidDisplay(s){const v=uidOf(s);return v?'UID '+v:'未识别 UID'}
function maskValue(s){s=String(s);return state.mask? ((s.length>8)?s.slice(0,11)+' ••••••••••• '+s.slice(-6):'••••••'):s}
function fingerprint(param){const uid=uidOf(param);if(uid)return 'ud:'+uid;return 'raw:'+param.replace(/\s+/g,'').toLowerCase()}
function parseImport(text){const lines=String(text).replace(/\r/g,'').split('\n'),out=[];let invalid=0;
for(let i=0;i<lines.length;i++){let line=lines[i].trim();if(!line||/^#|^\/\//.test(line))continue;
let note='',param='';const cookieStart=/^(?:kpn|kpf|did|ud|userId|client_key|kuaishou\.api_st|Cookie)\s*=/i.test(line);
if(cookieStart){param=line.replace(/^Cookie\s*:\s*/i,'')}else{
let sep=line.match(/^(.{1,80}?)\s*(?:[|｜]|\t|\s+=>\s+|\s+=\s+|\s*：\s*|\s*:\s*)\s*((?:kpn|kpf|did|ud|userId|client_key|kuaishou\.api_st)[=;].*)$/i);
if(!sep)sep=line.match(/^(.{1,60}?)\s*=\s*((?:kpn|kpf|did|ud|userId|client_key|kuaishou\.api_st)\s*=.*)$/i);
if(sep){note=sep[1].trim();param=sep[2].trim()}
else if(i+1<lines.length&&/^(?:kpn|kpf|did|ud|userId|client_key)\s*=/i.test(lines[i+1].trim())){note=line.replace(/[:：=|\s]+$/,'').trim();param=lines[++i].trim()}
else if(line.includes(';')&&/(?:ud|did|client_key)\s*=/.test(line)){param=line}
}
if(!param||!/(?:^|;)\s*(?:ud|userId|did|client_key|kpn)\s*=/i.test(param)){invalid++;continue}
out.push({note:note||'账号'+String(out.length+1).padStart(2,'0'),param});}
return {accounts:out,invalid};}
function importAccounts(items){let added=0,updated=0,skipped=0;const found=new Map(state.accounts.map(a=>[fingerprint(a.param),a]));for(const item of items){const param=String(item.param||'').trim(),note=String(item.note||'').trim();if(!param){skipped++;continue}const k=fingerprint(param),exist=found.get(k);if(exist){if(item.rid&&!exist.rid)exist.rid=String(item.rid);if(exist.param!==param){exist.param=param;updated++}else skipped++;if(item.renameExisting&&note)exist.note=note;}else{const account={id:id(),note:note||'账号'+String(state.accounts.length+1).padStart(2,'0'),param,enabled:true,status:'',lastResult:'',rid:String(item.rid||'')};state.accounts.push(account);state.selection.push(account.id);found.set(k,account);added++}}
save();render();return {added,updated,skipped};}
function render(){renderAccounts();renderCounts();renderQueue();updateAvatar();$('maskSwitch').checked=state.mask}
function renderCounts(){$('countTotal').textContent=state.accounts.length;$('countSelected').textContent=state.accounts.filter(a=>state.selection.includes(a.id)).length;$('countSuccess').textContent=state.success;$('countError').textContent=state.error;$('accSubtitle').textContent=state.accounts.length+' 个账号';}
function renderAccounts(){const query=$('searchInput').value.trim().toLowerCase();const items=state.accounts.filter(a=>!query||a.note.toLowerCase().includes(query)||a.param.toLowerCase().includes(query));$('accountList').innerHTML=items.map((a,n)=>{const checked=state.selection.includes(a.id),css=a.status==='成功'?'ok':(a.status==='失败'||a.status==='部分完成')?'bad':'';return `<div class="acc ${checked?'checked':''}"><input type="checkbox" data-choose="${escapeHtml(a.id)}" ${checked?'checked':''} aria-label="选中${escapeHtml(a.note)}"><span class="acc-index">${String(n+1).padStart(2,'0')}</span><div class="acc-main"><div class="acc-title">${escapeHtml(a.note)}</div><div class="acc-sub">${escapeHtml(uidDisplay(a.param))} · ${escapeHtml(maskValue(a.param))}</div><div class="acc-state ${css}">${escapeHtml(a.status||'待检测')}${a.lastResult?' · '+escapeHtml(a.lastResult):''}${a.rid?' · roundId已保存':''}</div></div><div class="acc-actions"><button class="iconbtn" data-edit="${escapeHtml(a.id)}" title="编辑备注及参数">✎</button><button class="iconbtn" data-delete="${escapeHtml(a.id)}" title="删除">✕</button></div></div>`}).join('');$('emptyAccounts').hidden=!!state.accounts.length;
$('selectAllBtn').textContent=state.accounts.length&&state.selection.length===state.accounts.length?'取消全选':'全选';}
function setTab(tab){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+tab))}
function modal(title,body,buttons){$('modalTitle').textContent=title;$('modalBody').innerHTML=body;$('modalActions').replaceChildren();buttons.forEach(b=>{const el=document.createElement('button');el.className=b.kind||'subtle';el.textContent=b.label;el.onclick=b.action;$('modalActions').appendChild(el)});$('modal').hidden=false}
function closeModal(){$('modal').hidden=true}
function openImport(){modal('批量导入账号',`<div class="info">支持一行一账号：「备注 = 完整参数」或直接粘贴 CK。自动识别 UID、去重并保留已设置的备注。不会自动向外发送这些参数。</div><label class="field">账号参数（可批量粘贴）<textarea id="importText" placeholder="鸭01 = kpn=NEBULA;kpf=ANDROID_PHONE;ud=123;client_key=...&#10;鸭02 = kpn=NEBULA;ud=456;client_key=..."></textarea></label><div class="toolbar"><button id="importPasteBtn" type="button" class="subtle">📋 一键粘贴剪贴板</button></div><p class="hint">以 # 开头的行会被跳过；相同 UID 的账号只保留一条。</p>`,[{label:'取消',action:closeModal},{label:'识别并保存',kind:'primary',action:()=>{const s=parseImport($('importText').value);if(!s.accounts.length){toast('未识别有效参数，请检查导入格式');return}const r=importAccounts(s.accounts);closeModal();log(`导入完成：新增 ${r.added}，参数更新 ${r.updated}，重复 ${r.skipped}，无效 ${s.invalid}`);toast(`已保存：新增 ${r.added}，更新 ${r.updated}`)}}]);$('importPasteBtn').onclick=async()=>{try{const content=native?window.DuckNative.readClipboard():await navigator.clipboard.readText();if(content){$('importText').value=content;toast('已粘贴账号数据')}else toast('剪贴板没有内容')}catch(e){toast('无法读取剪贴板，请手动粘贴')}};}
function openEdit(a){const fresh=!a;modal(fresh?'新建账号':'编辑账号',`<label class="field">自定义备注<input id="editNote" maxlength="80" placeholder="例如：鸭金01、鸭曲02"></label><label class="field">完整账号参数<textarea id="editParam" spellcheck="false" placeholder="kpn=NEBULA;kpf=ANDROID_PHONE;ud=...;client_key=..."></textarea></label><p class="hint">账号参数属于敏感凭证，请不要发到公开聊天或公开仓库。</p>`,[{label:'取消',action:closeModal},{label:'保存',kind:'primary',action:()=>{const note=$('editNote').value.trim(),param=$('editParam').value.trim();if(!param||!/(?:ud|did|client_key|kpn)\s*=/.test(param)){toast('请输入有效账号参数');return}if(fresh){const r=importAccounts([{note:note||'新账号',param}]);if(!r.added&&!r.updated){toast('账号已经存在');return}}else{if(state.accounts.some(x=>x.id!==a.id&&fingerprint(x.param)===fingerprint(param))){toast('其他账号已有相同 UID，不能重复');return}a.note=note||a.note;a.param=param;a.status='';a.lastResult='';save();render();}closeModal();toast('账号已保存')}}]);if(a){$('editNote').value=a.note;$('editParam').value=a.param;}}
function removeAccount(a){modal('删除账号',`<p class="hint">确定删除「${escapeHtml(a.note)}」？本操作只删除本地保存的参数，无法撤销。</p>`,[{label:'取消',action:closeModal},{label:'删除',kind:'danger',action:()=>{state.accounts=state.accounts.filter(x=>x.id!==a.id);state.selection=state.selection.filter(x=>x!==a.id);save();render();closeModal();toast('已删除')}}])}
function renderLogs(){$('logConsole').textContent=state.logs.length?state.logs.map(e=>`[${e.time}] ${e.kind==='error'?'✗':e.kind==='ok'?'✓':'•'} ${e.msg}`).join('\n'):'暂无日志';$('logConsole').scrollTop=$('logConsole').scrollHeight;}
function getConfig(){return {task:$('taskType').value,target:Math.min(100,Math.max(1,+$('taskTarget').value||3)),limit:Math.min(10000,Math.max(1,+$('taskLimit').value||800)),scope:$('taskScope').value,mode:$('taskMode').value,delay:Math.min(120,Math.max(1,+$('taskDelay').value||3)),timeout:Math.min(60,Math.max(5,+$('taskTimeout').value||15))}}
const sleep=t=>new Promise(resolve=>setTimeout(resolve,t));
async function nativeCheck(account,timeout){if(!native)throw Error('浏览器预览不能直接调用账号接口，请安装原生 Android 构建版');const request='req'+(++state.seq)+'-'+Date.now();return await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{state.pending.delete(request);reject(Error('超时（'+timeout+'秒）'))},(timeout+2)*1000);state.pending.set(request,{resolve,reject,timer});try{window.DuckNative.checkStatus(request,account.param,String(timeout))}catch(e){clearTimeout(timer);state.pending.delete(request);reject(e)}})}
// Runs the original APK's DuckClient through an Android-only adapter.
async function nativeOriginal(account,cfg){
 if(!native||typeof window.DuckNative.runOriginal!=='function')throw Error('没有接入原版安卓执行引擎，网页预览不支持实际任务');
 const request='original-'+(++state.seq)+'-'+Date.now();
 return new Promise((resolve,reject)=>{
  state.pending.set(request,{resolve,reject,timer:0,accountId:account.id});
  try{window.DuckNative.runOriginal(request,account.param,cfg.task,String(cfg.target),String(cfg.limit),String(account.rid||''))}
  catch(e){state.pending.delete(request);reject(e)}
 });
}
window.DuckOriginalEvent=(request,kind,msg)=>{
 const pending=state.pending.get(request);
 if(!pending)return;
 const a=state.accounts.find(x=>x.id===pending.accountId);
 if(kind==='log'&&a)log(a.note+'：'+String(msg).slice(0,300));
};
window.DuckNativeResult=(request,ok,response)=>{const p=state.pending.get(request);if(!p)return;clearTimeout(p.timer);state.pending.delete(request);let obj;try{obj=JSON.parse(response)}catch(e){obj={message:String(response)}};if(ok)p.resolve(obj);else p.reject(Error(obj.message||'请求失败'))};
function renderQueue(){const q=state.queue,finished=q.filter(j=>['成功','失败','停止','部分完成'].includes(j.status)).length;$('jobProgress').textContent=state.running?`${finished} / ${q.length} 已完成`:(q.length?`${finished} / ${q.length} 完成`:'待执行');$('progressBar').style.width=q.length?(finished/q.length*100)+'%':'0%';$('jobQueue').innerHTML=q.length?q.map(j=>`<div class="job"><span><strong>${escapeHtml(j.note)}</strong><small>${escapeHtml(j.uid)}${j.detail?' · '+escapeHtml(j.detail):''}</small></span><em class="${j.status==='成功'?'ok':(j.status==='失败'||j.status==='部分完成')?'bad':''}">${escapeHtml(j.status)}</em></div>`).join(''):'<p class="muted">执行任务后，这里将显示每个账号的真实结果。</p>';}
async function startBatch(){
 if(state.running){toast('已有任务在运行');return}
 if(!native||typeof window.DuckNative.runOriginal!=='function'){
  toast('网页预览不能运行游戏接口，需要 Android 安装版');log('原版执行引擎仅在 Android 安装版中使用','error');return;
 }
 const cfg=getConfig(),accounts=state.accounts.filter(a=>cfg.scope==='all'||state.selection.includes(a.id));
 if(!accounts.length){toast('请先导入并选择账号');setTab('accounts');return}
 state.running=true;state.stopped=false;state.paused=false;state.success=0;state.error=0;
 state.queue=accounts.map(a=>({id:a.id,note:a.note,uid:uidDisplay(a.param),status:'待执行'}));
 $('startBtn').disabled=true;$('stopBtn').disabled=false;$('pauseBtn').disabled=false;$('pauseBtn').textContent='Ⅱ 暂停队列';render();
 log(`启动原版任务 [${$('taskType').selectedOptions[0].textContent}]：${accounts.length}账号，${cfg.mode==='parallel'?'2 并发':'顺序'}，账号间隔${cfg.delay}秒`);
 let cursor=0;const workers=cfg.mode==='parallel'?2:1;
 async function worker(){
  while(!state.stopped){
   while(state.paused&&!state.stopped)await sleep(250);
   if(state.stopped)break;
   const index=cursor++;if(index>=accounts.length)break;
   const a=accounts[index],j=state.queue[index];j.status='执行中';a.status='执行中';renderQueue();renderAccounts();
   try{
    const result=await nativeOriginal(a,cfg);
    // Even if stopped, preserve last roundId returned by the genuine engine.
    if(result.rid){a.rid=String(result.rid);save()}
    if(result.eggBefore!==undefined&&result.eggAfter!==undefined)j.detail='蛋 '+result.eggBefore+' → '+result.eggAfter+'，上报 '+(result.reports||0)+' 次';
    if(state.stopped){j.status='停止';a.status='停止'}
    else {
     const err=String(result.error||'');
     j.status=err?'部分完成':'成功';a.status=j.status;
     if(err)state.error++;else state.success++;
     let desc=String(result.summary||'原版接口执行完成');
     if(result.data){
      const data=typeof result.data==='object'?JSON.stringify(result.data):String(result.data);
      desc+=' · '+data.slice(0,230);
     }
     a.lastResult=desc.slice(0,250);
     log(a.note+'（'+uidDisplay(a.param)+'）：'+a.lastResult,err?'error':'ok');
    }
   }catch(e){
    j.status=state.stopped?'停止':'失败';a.status=j.status;
    if(!state.stopped)state.error++;
    a.lastResult=String(e.message||e).slice(0,200);
    log(`${a.note}：${a.lastResult}`,'error');
   }
   renderCounts();renderQueue();renderAccounts();
   if(cursor<accounts.length&&!state.stopped)await sleep(cfg.delay*1000);
  }
 }
 await Promise.all(Array.from({length:Math.min(workers,accounts.length)},worker));
 state.queue.filter(j=>j.status==='待执行'||j.status==='执行中').forEach(j=>j.status='停止');
 state.running=false;state.paused=false;$('startBtn').disabled=false;$('stopBtn').disabled=true;$('pauseBtn').disabled=true;
 log(state.stopped?'任务已停止':`任务完成：成功 ${state.success} / 异常或部分完成 ${state.error}`);
 render();
}
function stopBatch(){
 if(!state.running)return;state.stopped=true;state.paused=false;$('stopBtn').disabled=true;$('pauseBtn').disabled=true;
 try{if(native)window.DuckNative.cancelAllOriginal()}catch(e){log('通知执行引擎停止失败：'+e.message,'error')}
 log('已通知原版引擎停止，并禁止新的账号入队；在途请求待原接口返回');
}
function togglePause(){
 if(!state.running)return;
 state.paused=!state.paused;
 $('pauseBtn').textContent=state.paused?'▶ 继续队列':'Ⅱ 暂停队列';
 log(state.paused?'队列已暂停：正在执行的原版请求会继续到结束':'队列已继续执行');
}
function backupPayload(){return JSON.stringify({app:'laoya-duck-v2',schema:2,exportedAt:new Date().toISOString(),accounts:state.accounts.map(a=>({note:a.note,param:a.param,enabled:a.enabled,rid:a.rid||''}))},null,2)}
function exportBackup(){const json=backupPayload();if(native){window.DuckNative.exportBackup(json);return}try{const blob=new Blob([json],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='老鸭账号备份-'+new Date().toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),4000);log('已导出账号备份（包含完整敏感参数，请妥善保管）')}catch(e){toast('导出失败 '+e.message)}}
function parseBackup(json){let obj=JSON.parse(json);if(!Array.isArray(obj.accounts))throw Error('备份 JSON 缺少 accounts 数组');const r=importAccounts(obj.accounts);for(const item of obj.accounts){if(item.rid){const a=state.accounts.find(x=>fingerprint(x.param)===fingerprint(item.param));if(a)a.rid=String(item.rid)}}save();log(`备份恢复：新增 ${r.added}、更新 ${r.updated}、重复 ${r.skipped}`);toast('备份已恢复：新增 '+r.added);}
window.DuckNativeBackup=json=>{try{parseBackup(json)}catch(e){toast('恢复失败：'+e.message)}};
window.DuckNativeNotice=msg=>toast(msg);
function imageChosen(file){if(!file||!file.type.startsWith('image/'))return;const reader=new FileReader;reader.onload=()=>{const img=new Image;img.onload=()=>{const c=document.createElement('canvas');c.width=180;c.height=180;const ctx=c.getContext('2d');const side=Math.min(img.width,img.height),sx=(img.width-side)/2,sy=(img.height-side)/2;ctx.drawImage(img,sx,sy,side,side,0,0,180,180);state.avatar=c.toDataURL('image/jpeg',.77);try{if(native)window.DuckNative.saveAvatar(state.avatar);else localStorage.setItem(KEYS.avatar,state.avatar);updateAvatar();toast('头像已保存')}catch(e){toast('头像保存失败：'+e.message)}};img.src=reader.result};reader.readAsDataURL(file)}
function openOriginal(){
 if(!native || !window.DuckNative.openOriginalApp){toast('原版页面只能在安装 APK 后打开');return}
 if(state.running){toast('请先停止当前批量任务');return}
 window.DuckNative.openOriginalApp();
}
function init(){readStorage();$('engineBadge').textContent=native?(window.DuckNative.engineInfo?window.DuckNative.engineInfo():'ANDROID · 待验证'):'WEB · 预览';$('engineBadge').classList.toggle('native',native);$('nativeHint').textContent=native?'Android 原生版本：原 APK 主 DEX 未改动；可直接打开原版页面，也可执行批量队列；数据使用系统密钥库加密。线上结果受网络与账户状态影响。':'网页预览：保存在浏览器 localStorage，无法直接运行快手接口。请勿在共享设备上导入真实账号参数。';render();renderLogs();log('老鸭版 V4.0 原 APK 增强工作台已启动'+(native?'，原版 DuckClient 可通过本地桥接调用':'，当前为网页预览模式'));
document.querySelectorAll('.tab').forEach(btn=>btn.onclick=()=>setTab(btn.dataset.tab));$('openOriginalBtn').onclick=openOriginal;$('openOriginalSettings').onclick=openOriginal;$('importBtn').onclick=openImport;$('addBtn').onclick=()=>openEdit(null);$('searchInput').oninput=renderAccounts;$('selectAllBtn').onclick=()=>{state.selection=state.selection.length===state.accounts.length?[]:state.accounts.map(x=>x.id);save();render()};$('accountList').onclick=e=>{const b=e.target.closest('[data-edit],[data-delete]');if(!b)return;const a=state.accounts.find(x=>x.id===(b.dataset.edit||b.dataset.delete));if(!a)return;b.dataset.edit?openEdit(a):removeAccount(a)};$('accountList').onchange=e=>{const t=e.target;if(!t.dataset.choose)return;const ids=new Set(state.selection);t.checked?ids.add(t.dataset.choose):ids.delete(t.dataset.choose);state.selection=[...ids];save();render()};$('startBtn').onclick=startBatch;$('taskType').onchange=()=>{$('farmFields').hidden=$('taskType').value!=='farm';$('startBtn').textContent=$('taskType').value==='farm'?'▶ 开始刷蛋':'▶ 开始批量查询'};$('stopBtn').onclick=stopBatch;$('pauseBtn').onclick=togglePause;$('copyLogsBtn').onclick=async()=>{const s=state.logs.map(e=>`[${e.time}] ${e.msg}`).join('\n');if(native){window.DuckNative.copyText(s);toast('日志已复制')}else try{await navigator.clipboard.writeText(s);toast('日志已复制')}catch(e){toast('复制失败')}};$('clearLogsBtn').onclick=()=>{state.logs=[];renderLogs()};$('closeModal').onclick=closeModal;$('modalScrim').onclick=closeModal;$('chooseAvatarBtn').onclick=$('avatarBtn').onclick=()=>$('avatarFile').click();$('avatarFile').onchange=e=>{imageChosen(e.target.files[0]);e.target.value=''};$('exportBtn').onclick=$('backupBtn').onclick=exportBackup;$('restoreBtn').onclick=()=>{if(native)window.DuckNative.importBackup();else $('backupFile').click()};$('backupFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{parseBackup(await f.text())}catch(err){toast('备份读取失败：'+err.message)}e.target.value=''};$('maskSwitch').onchange=e=>{state.mask=e.target.checked;save();renderAccounts()};$('clearAccountsBtn').onclick=()=>modal('清空账号库','<p class="hint">确定彻底删除当前设备保存的所有账号和参数吗？建议先导出一份备份。</p>',[{label:'取消',action:closeModal},{label:'确认清空',kind:'danger',action:()=>{if(state.running){toast('请先停止任务');return}state.accounts=[];state.selection=[];save();render();closeModal();log('已清空全部账号')} }]);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
window.__duckTest={parseImport,importAccounts,fingerprint};
})();
