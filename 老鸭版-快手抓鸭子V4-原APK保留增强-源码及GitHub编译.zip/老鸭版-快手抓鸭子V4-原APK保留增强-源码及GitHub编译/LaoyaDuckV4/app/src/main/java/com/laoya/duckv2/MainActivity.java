package com.laoya.duckv2;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Context;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.ValueCallback;
import android.widget.Toast;
import android.view.Window;
import android.view.View;
import org.json.JSONObject;
import org.json.JSONArray;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final String PREFS="laoya_v2_private";
    private static final String KEY_NAME="LaoyaDuckV2DataKey";
    private static final int REQUEST_IMAGE=2101, REQUEST_EXPORT=2102, REQUEST_IMPORT=2103;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService pool=Executors.newFixedThreadPool(2);
    private WebView browser;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingExport="";
    private final ConcurrentHashMap<String,AtomicBoolean> originalStops = new ConcurrentHashMap<>();
    private volatile OriginalDuckEngine originalEngine;

    @Override public void onCreate(Bundle state){super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7,13,24));
        getWindow().setNavigationBarColor(Color.rgb(7,13,24));
        browser=new WebView(this);
        browser.setBackgroundColor(Color.rgb(7,13,24));
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setAllowFileAccess(true);
        browser.getSettings().setAllowFileAccessFromFileURLs(false);
        browser.getSettings().setAllowUniversalAccessFromFileURLs(false);
        browser.addJavascriptInterface(new Bridge(),"DuckNative");
        browser.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
                Uri uri=r.getUrl();
                if("file".equalsIgnoreCase(uri.getScheme()) && "android_asset".equalsIgnoreCase(uri.getHost()))return false;
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return !url.startsWith("file:///android_asset/");}
        });
        browser.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;
                try{Intent intent=params.createIntent();startActivityForResult(intent,REQUEST_IMAGE);return true;}
                catch(Exception e){fileCallback=null;notifyJs("无法打开相册："+e.getMessage());return false;}
            }
        });
        setContentView(browser);
        browser.loadUrl("file:///android_asset/index.html");
    }
    private void runJs(String js){ui.post(()->{if(browser!=null)browser.evaluateJavascript(js,null);});}
    private void notifyJs(String s){runJs("window.DuckNativeNotice("+JSONObject.quote(s)+")");}
    private SharedPreferences pref(){return getSharedPreferences(PREFS,MODE_PRIVATE);}
    private SecretKey key() throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(!ks.containsAlias(KEY_NAME)){
            KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            gen.init(new KeyGenParameterSpec.Builder(KEY_NAME,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build());
            gen.generateKey();
        }
        return (SecretKey)ks.getKey(KEY_NAME,null);
    }
    private synchronized String encrypt(String plaintext) throws Exception {
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
        byte[] iv=cipher.getIV(),enc=cipher.doFinal(plaintext.getBytes(StandardCharsets.UTF_8));
        byte[] out=new byte[iv.length+enc.length];System.arraycopy(iv,0,out,0,iv.length);System.arraycopy(enc,0,out,iv.length,enc.length);
        return Base64.encodeToString(out,Base64.NO_WRAP);
    }
    private synchronized String decrypt(String input) throws Exception {
        byte[] full=Base64.decode(input,Base64.NO_WRAP);if(full.length<29)throw new Exception("加密数据损坏");
        byte[] iv=new byte[12],enc=new byte[full.length-12];System.arraycopy(full,0,iv,0,12);System.arraycopy(full,12,enc,0,enc.length);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,iv));
        return new String(cipher.doFinal(enc),StandardCharsets.UTF_8);
    }
    private synchronized void secureSave(String name,String data){try{
        String previous=pref().getString(name,"");String encrypted=encrypt(data);
        // 双份保存：若最新记录损坏，可恢复上一个版本。
        pref().edit().putString(name+"_previous",previous).putString(name,encrypted).commit();
    }catch(Exception e){notifyJs("安全保存失败："+e.getMessage());}}
    private synchronized String secureLoad(String name){
        for(String slot:new String[]{name,name+"_previous"})try{String v=pref().getString(slot,"");if(!v.isEmpty())return decrypt(v);}catch(Exception ignored){}
        return "";
    }
    private String getResponse(HttpURLConnection c,int code) throws Exception {
        InputStream input=code>=400?c.getErrorStream():c.getInputStream();if(input==null)return "";
        try(InputStream in=input;ByteArrayOutputStream bos=new ByteArrayOutputStream()){
            byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){bos.write(buf,0,n);if(bos.size()>60000)break;}
            return bos.toString("UTF-8");
        }
    }
    private void checkStatusInternal(String requestId,String cookie,int timeout){
        HttpURLConnection c=null;boolean ok=false;String result;
        try{
            if(cookie.isEmpty()||cookie.contains("\n")||cookie.contains("\r"))throw new IllegalArgumentException("账号参数无效");
            URL url=new URL("https://nebula.kuaishou.com/rest/n/encourage/game/luckyDuck/statusRefresh");
            c=(HttpURLConnection)url.openConnection();
            c.setRequestMethod("GET");c.setConnectTimeout(timeout*1000);c.setReadTimeout(timeout*1000);
            c.setInstanceFollowRedirects(false);
            c.setRequestProperty("Cookie",cookie);
            c.setRequestProperty("Accept","application/json");
            c.setRequestProperty("Referer","https://nebula.kuaishou.com/games/lucky-duck/home?layoutType=4&source=TASK");
            c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36");
            c.setRequestProperty("X-Requested-With","com.kuaishou.nebula");
            int code=c.getResponseCode();String body=getResponse(c,code);
            if(code<200||code>=300)throw new Exception("HTTP "+code+" "+(body.length()>120?body.substring(0,120):body));
            JSONObject json=new JSONObject(body);
            int apiCode=json.optInt("result",json.optInt("code",0));
            if(apiCode!=0&&apiCode!=1&&apiCode!=200)throw new Exception(json.optString("error_msg",json.optString("message","服务端错误 "+apiCode)));
            // 只能报告真实的远端响应；不凭空生成余额或奖励数据。
            String summary="接口返回成功";
            JSONObject data=json.optJSONObject("data");
            if(data!=null){StringBuilder sb=new StringBuilder("响应已获取");
                if(data.has("eggBalance"))sb.append(" · 鸭蛋 ").append(data.opt("eggBalance"));
                if(data.has("eggNow"))sb.append(" · 当前蛋 ").append(data.opt("eggNow"));
                if(data.has("balance"))sb.append(" · 余额 ").append(data.opt("balance"));
                summary=sb.toString();}
            result=new JSONObject().put("message","查询成功").put("summary",summary).put("http",code).toString();ok=true;
        }catch(Exception e){try{result=new JSONObject().put("message",e.getClass().getSimpleName()+"："+e.getMessage()).toString();}catch(Exception ignored){result="{\"message\":\"网络错误\"}";}}
        finally{if(c!=null)c.disconnect();}
        final boolean success=ok;final String body=result;
        runJs("window.DuckNativeResult("+JSONObject.quote(requestId)+","+success+","+JSONObject.quote(body)+")");
    }
    private OriginalDuckEngine original() throws Exception {
        if (originalEngine==null) synchronized(this) {
            if(originalEngine==null)originalEngine=new OriginalDuckEngine(getApplicationContext());
        }
        return originalEngine;
    }
    private void runOriginalInternal(String requestId,String cookie,String action,int target,int limit,String rid){
        AtomicBoolean cancel=new AtomicBoolean(false);
        originalStops.put(requestId,cancel);
        try{
            JSONObject response=original().execute(cookie,action,target,limit,rid,
                message->runJs("window.DuckOriginalEvent("+JSONObject.quote(requestId)+","+JSONObject.quote("log")+","+JSONObject.quote(message)+")"),cancel);
            runJs("window.DuckNativeResult("+JSONObject.quote(requestId)+",true,"+JSONObject.quote(response.toString())+")");
        }catch(Exception e){
            String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
            JSONObject data=new JSONObject();try{data.put("message",msg);}catch(Exception ignored){}
            runJs("window.DuckNativeResult("+JSONObject.quote(requestId)+",false,"+JSONObject.quote(data.toString())+")");
        }finally{originalStops.remove(requestId);}
    }
    private final class Bridge {
        @JavascriptInterface public void openOriginalApp(){
            ui.post(()->{
                try {
                    Intent intent = new Intent();
                    intent.setClassName(getPackageName(), "com.chengfeng.duckassist.MainActivity");
                    startActivity(intent);
                } catch (Exception e) {
                    notifyJs("原版界面打开失败："+e.getMessage());
                }
            });
        }
        @JavascriptInterface public String loadData(){return secureLoad("accounts");}
        @JavascriptInterface public void saveData(String data){if(data.length()>5_000_000){notifyJs("账号数据过大");return;}secureSave("accounts",data);}
        @JavascriptInterface public String loadAvatar(){return secureLoad("avatar");}
        @JavascriptInterface public void saveAvatar(String image){if(image.length()>250_000){notifyJs("头像过大");return;}secureSave("avatar",image);}
        @JavascriptInterface public void checkStatus(String requestId,String cookie,String timeout){
            int t=15;try{t=Integer.parseInt(timeout);}catch(Exception ignored){}final int s=Math.max(5,Math.min(60,t));
            pool.execute(()->checkStatusInternal(requestId,cookie,s));
        }
        @JavascriptInterface public void runOriginal(String requestId,String cookie,String action,String target,String limit,String rid){
            if(requestId==null||requestId.length()>100||cookie==null||cookie.length()>16000)return;
            if(!action.equals("farm")&&!action.equals("balance")&&!action.equals("status")&&!action.equals("chances")&&!action.equals("probe")&&!action.equals("playable"))return;
            int t=3,l=800;try{t=Integer.parseInt(target);l=Integer.parseInt(limit);}catch(Exception ignored){}
            final int targetVal=Math.max(1,Math.min(100,t)),limitVal=Math.max(1,Math.min(10000,l));
            pool.execute(()->runOriginalInternal(requestId,cookie,action,targetVal,limitVal,rid));
        }
        @JavascriptInterface public void stopOriginal(String requestId){
            AtomicBoolean cancel=originalStops.get(requestId);if(cancel!=null)cancel.set(true);
        }
        @JavascriptInterface public void cancelAllOriginal(){for(AtomicBoolean flag:originalStops.values())flag.set(true);}
        @JavascriptInterface public String engineInfo(){
            try{original();return "原版 DuckClient DEX 已载入";}catch(Exception e){return "执行引擎载入失败："+e.getMessage();}
        }
        @JavascriptInterface public void exportBackup(String data){if(data.length()>5_000_000){notifyJs("导出数据太大");return;}ui.post(()->{
            pendingExport=data;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"老鸭账号备份-"+System.currentTimeMillis()+".json");startActivityForResult(i,REQUEST_EXPORT);
        });}
        @JavascriptInterface public void importBackup(){ui.post(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");startActivityForResult(i,REQUEST_IMPORT);});}
        @JavascriptInterface public String readClipboard(){
            try {
                ClipboardManager mgr=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip=mgr==null?null:mgr.getPrimaryClip();
                if(clip==null||clip.getItemCount()==0)return "";
                CharSequence value=clip.getItemAt(0).coerceToText(MainActivity.this);
                return value==null?"":value.toString().substring(0,Math.min(value.length(),500_000));
            }catch(Exception e){return "";}
        }
        @JavascriptInterface public void copyText(String txt){ui.post(()->{ClipboardManager m=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);m.setPrimaryClip(ClipData.newPlainText("老鸭运行日志",txt));});}
    }
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
        if(req==REQUEST_IMAGE){if(fileCallback!=null){fileCallback.onReceiveValue(result==RESULT_OK&&data!=null?new Uri[]{data.getData()}:null);fileCallback=null;}return;}
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try{
            if(req==REQUEST_EXPORT){try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(pendingExport.getBytes(StandardCharsets.UTF_8));}pendingExport="";notifyJs("备份已导出；注意：备份文件包含账号参数，请妥善保管");}
            if(req==REQUEST_IMPORT){try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream b=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){b.write(buf,0,n);if(b.size()>5_000_000)throw new Exception("备份超过 5 MB");}
                String json=b.toString("UTF-8");runJs("window.DuckNativeBackup("+JSONObject.quote(json)+")");
            }}
        }catch(Exception e){notifyJs("文件操作失败："+e.getMessage());}
    }
    @Override public void onBackPressed(){if(browser.canGoBack())browser.goBack();else super.onBackPressed();}
    @Override public void onDestroy(){for(AtomicBoolean cancel:originalStops.values())cancel.set(true);pool.shutdownNow();if(browser!=null){browser.removeJavascriptInterface("DuckNative");browser.destroy();browser=null;}super.onDestroy();}
}
