// node docs/test_parser.js
const vm=require('vm'),fs=require('fs'),assert=require('assert'),path=require('path');
const js=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/app.js'),'utf8');
const local=new Map();const nodes=new Map();
function el(name){if(!nodes.has(name)){const obj={value:'',textContent:'',innerHTML:'',hidden:false,checked:true,dataset:{},style:{},classList:{toggle(){},add(){}},setAttribute(){},addEventListener(){},replaceChildren(){},appendChild(){},scrollTop:0,scrollHeight:0};nodes.set(name,obj)}return nodes.get(name)}
const document={readyState:'complete',getElementById:el,querySelectorAll:()=>[]};
const window={};const localStorage={getItem:k=>local.get(k)||null,setItem:(k,v)=>local.set(k,v)};
vm.runInNewContext(js,{window,document,localStorage,console,Math,Date,JSON,Map,Set,Promise,setTimeout,clearTimeout,URL,Blob,FileReader:function(){},Image:function(){}});
const parser=window.__duckTest;
let r=parser.parseImport('鸭01 = kpn=NEBULA;ud=123;client_key=x\n鸭02|kpn=NEBULA;ud=456;client_key=y\n# ignore\nkpn=NEBULA;ud=789;client_key=z');
assert.strictEqual(r.accounts.length,3);assert.strictEqual(r.accounts[0].note,'鸭01');
assert.strictEqual(r.accounts[1].note,'鸭02');assert.strictEqual(r.accounts[2].note,'账号03');
let s=parser.importAccounts(r.accounts);assert.strictEqual(s.added,3);
s=parser.importAccounts(r.accounts);assert.strictEqual(s.added,0);assert.strictEqual(s.skipped,3);
assert.strictEqual(el('countTotal').textContent,3);
assert(local.get('laoya_duck_v4_data').includes('鸭01'));
r=parser.parseImport('备注：\nkpn=NEBULA;ud=112;client_key=xxx');assert.strictEqual(r.accounts[0].note,'备注');
console.log('PASS: 备注/参数解析、批量导入、去重、持久保存、两行格式');
