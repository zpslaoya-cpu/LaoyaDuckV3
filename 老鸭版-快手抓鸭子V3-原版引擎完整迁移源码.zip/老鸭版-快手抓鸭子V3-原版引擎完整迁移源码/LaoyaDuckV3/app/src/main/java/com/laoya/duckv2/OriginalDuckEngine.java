package com.laoya.duckv2;

import android.content.Context;
import dalvik.system.DexClassLoader;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Thin adapter over the EXACT DuckClient bytecode from the user's base(3).apk.
 * No endpoints, tokens or response values have been reimplemented or invented.
 * The original engine is stored as assets/original-engine.jar (classes.dex inside).
 */
final class OriginalDuckEngine {
    interface Events { void log(String message); }
    private final Class<?> clientClass;
    private final Class<?> logClass;
    private final Class<?> stopClass;
    private final Constructor<?> constructor;
    private final Method probeHost, eggBalance, freeTimes, playable, farm;

    OriginalDuckEngine(Context context) throws Exception {
        File output = new File(context.getCodeCacheDir(),"original-duck-engine-v3.jar");
        if (!output.exists() || output.length()<1024) {
            File temp = new File(context.getCodeCacheDir(),"original-duck-engine.tmp");
            if (temp.exists() && !temp.delete()) throw new Exception("无法重置临时引擎文件");
            try (InputStream in=context.getAssets().open("original-engine.jar");
                 OutputStream out=new FileOutputStream(temp)) {
                byte[] buffer=new byte[8192]; int n;
                while ((n=in.read(buffer))!=-1)out.write(buffer,0,n);
            }
            if (!temp.setReadOnly()) throw new Exception("无法设置代码文件只读");
            if (output.exists()&&!output.delete())throw new Exception("无法替换旧引擎");
            if (!temp.renameTo(output)) throw new Exception("无法安装原版执行引擎");
        }
        // Class loader is private to this app. Nothing downloaded or loaded from the network.
        DexClassLoader loader=new DexClassLoader(output.getAbsolutePath(),context.getCodeCacheDir().getAbsolutePath(),null,context.getClassLoader());
        clientClass=Class.forName("com.chengfeng.duckassist.DuckClient",true,loader);
        logClass=Class.forName("com.chengfeng.duckassist.DuckClient$Log",true,loader);
        stopClass=Class.forName("com.chengfeng.duckassist.DuckClient$Stop",true,loader);
        constructor=clientClass.getDeclaredConstructor(String.class);
        constructor.setAccessible(true);
        probeHost=clientClass.getDeclaredMethod("probeHost",logClass);
        eggBalance=clientClass.getDeclaredMethod("eggBalance");
        freeTimes=clientClass.getDeclaredMethod("freeTimes");
        playable=clientClass.getDeclaredMethod("playable",logClass);
        farm=clientClass.getDeclaredMethod("farm",int.class,int.class,String.class,logClass,stopClass);
        for (Method method:new Method[]{probeHost,eggBalance,freeTimes,playable,farm}) method.setAccessible(true);
    }

    private Object createLog(Events events) {
        InvocationHandler handler=(proxy,method,args)->{
            if (method.getName().equals("log")) {if (args!=null&&args.length>0)events.log(String.valueOf(args[0]));return null;}
            if (method.getName().equals("toString"))return "LaoyaDuckLogger";
            if (method.getName().equals("hashCode"))return System.identityHashCode(proxy);
            if (method.getName().equals("equals"))return proxy==args[0];
            return null;
        };
        return Proxy.newProxyInstance(logClass.getClassLoader(),new Class[]{logClass},handler);
    }
    private Object createStop(AtomicBoolean cancel) {
        return Proxy.newProxyInstance(stopClass.getClassLoader(),new Class[]{stopClass},(proxy,method,args)->{
            if (method.getName().equals("stopped"))return cancel.get();
            if (method.getName().equals("toString"))return "LaoyaDuckStop";
            if (method.getName().equals("hashCode"))return System.identityHashCode(proxy);
            if (method.getName().equals("equals"))return proxy==args[0];
            return null;
        });
    }
    private static Object access(Object obj,String name) throws Exception {
        java.lang.reflect.Field f=obj.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(obj);
    }
    private static Object unwrap(Object data) {
        if (data instanceof Map) {
            JSONObject out=new JSONObject();
            for (Map.Entry<?,?> item:((Map<?,?>)data).entrySet())try{
                String key=String.valueOf(item.getKey());
                if(key.toLowerCase().contains("token")||key.toLowerCase().contains("cookie")||key.equals("ck"))continue;
                out.put(key,unwrap(item.getValue()));
            }catch(Exception ignored){}
            return out;
        }
        if (data instanceof java.util.List){org.json.JSONArray a=new org.json.JSONArray();for(Object v:(java.util.List<?>)data)a.put(unwrap(v));return a;}
        if(data instanceof Boolean||data instanceof Number||data instanceof String)return data;
        return String.valueOf(data);
    }
    JSONObject execute(String ck,String action,int target,int limit,String roundId,Events events,AtomicBoolean cancel) throws Exception {
        if(ck==null||ck.length()<15||ck.length()>16000||ck.contains("\r")||ck.contains("\n"))throw new IllegalArgumentException("账号 CK 参数无效");
        Object client=constructor.newInstance(ck);
        Object logger=createLog(events);
        try{
            JSONObject output=new JSONObject();output.put("action",action);
            if (action.equals("probe")){
                Object host=probeHost.invoke(client,logger);
                output.put("host",String.valueOf(host));
                output.put("summary",host==null?"域名探测无结果":"分片域名探测完成");
            } else if (action.equals("balance")||action.equals("status")) {
                Object result=eggBalance.invoke(client);
                output.put("data",unwrap(result));
                output.put("summary","原版鸭蛋/鸭币余额查询完成");
            } else if (action.equals("chances")) {
                Object result=freeTimes.invoke(client);
                output.put("data",unwrap(result));
                output.put("summary","原版免费次数查询完成");
            } else if (action.equals("playable")) {
                Object ok=playable.invoke(client,logger);
                output.put("playable",(Boolean)ok);
                output.put("summary",((Boolean)ok)?"原版检测：有可用局次":"原版检测：当前无可用局次");
            } else if (action.equals("farm")) {
                events.log("原版启动：目标 "+target+" 蛋，上报上限 "+limit);
                // Mirror the original app's ordering: probe endpoints before starting each game session.
                Object host=probeHost.invoke(client,logger);
                if(host==null||String.valueOf(host).isEmpty())throw new Exception("四个分片域名未连通，或账号 CK 已失效");
                if(cancel.get())throw new Exception("任务已经停止");
                Object result=farm.invoke(client,target,limit,roundId==null?"":roundId,logger,createStop(cancel));
                int before=(Integer)access(result,"eggBefore"),after=(Integer)access(result,"eggAfter"),reports=(Integer)access(result,"reports");
                String rid=String.valueOf(access(result,"rid")),err=String.valueOf(access(result,"err"));
                output.put("eggBefore",before);
                output.put("eggAfter",after);
                output.put("eggDelta",after-before);
                output.put("reports",reports);
                output.put("coin",(Integer)access(result,"coin"));
                output.put("rid",rid.equals("null")?"":rid);
                output.put("reused",(Boolean)access(result,"reused"));
                output.put("error",err.equals("null")?"":err);
                output.put("summary","原版执行返回：上报 "+reports+" 次，蛋 "+before+" → "+after+(err.isEmpty()?"":"；"+err));
            } else throw new IllegalArgumentException("未知任务类型："+action);
            return output;
        }catch(InvocationTargetException e){Throwable reason=e.getTargetException();throw new Exception(reason==null?e.toString():reason.getClass().getSimpleName()+"："+reason.getMessage(),reason);}
    }
}
