const vm=require('vm'), fs=require('fs'), path=require('path'), assert=require('assert');
const js=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/app.js'),'utf8');
const nodes=new Map();let saved='',calls=[];
function element(id){if(!nodes.has(id))nodes.set(id,{value:'',textContent:'',innerHTML:'',hidden:false,disabled:false,checked:true,dataset:{},style:{},classList:{toggle(){}},setAttribute(){},replaceChildren(){},appendChild(){},scrollTop:0,scrollHeight:0,selectedOptions:[{textContent:'原版抓鸭刷蛋'}]});return nodes.get(id)}
const document={readyState:'complete',getElementById:element,querySelectorAll:()=>[]};
const window={DuckNative:{loadData:()=>saved,saveData:v=>saved=v,loadAvatar:()=>'',engineInfo:()=> '原版引擎已加载',runOriginal:(id,ck,kind,target,limit,rid)=>{calls.push({ck,kind,target,limit,rid});setTimeout(()=>window.DuckNativeResult(id,true,JSON.stringify({rid:'r'+ck.match(/ud=(\d+)/)[1],reports:100,eggBefore:0,eggAfter:1,summary:'测试桩回调成功'})),0)},cancelAllOriginal:()=>{} }};
const ctx={window,document,localStorage:{getItem(){return null},setItem(){}},console,Math,Date,JSON,Map,Set,Promise,setTimeout,clearTimeout};
vm.runInNewContext(js,ctx);const api=window.__duckTest;
api.importAccounts([{note:'鸭01',param:'kpn=NEBULA;ud=123;client_key=mock_1'},{note:'鸭02',param:'kpn=NEBULA;ud=456;client_key=mock_2'}]);
element('taskType').value='farm';element('taskTarget').value='3';element('taskLimit').value='800';element('taskScope').value='all';element('taskMode').value='parallel';element('taskDelay').value='1';element('taskTimeout').value='15';
(async()=>{await element('startBtn').onclick();assert.equal(calls.length,2);assert(calls.every(c=>c.kind==='farm'&&c.target==='3'&&c.limit==='800'));assert(saved.includes('"rid":"r123"'));assert(saved.includes('"rid":"r456"'));assert.equal(element('countSuccess').textContent,2);console.log('PASS: 原版桥接调用、双账号任务、roundId 续接保存、回调计数（模拟引擎，无真实网络）')})().catch(e=>{console.error(e);process.exitCode=1});
