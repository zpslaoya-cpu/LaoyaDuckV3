# 🦆 老鸭版 · 快手抓鸭子 V3.0 — 原版功能迁移工程

## 本次与 V2 不同的地方

V2 只有账号管理和模拟队列。**V3 把用户上传 `base(3).apk` 的 `classes.dex` 原封不动打包为 Android 资源 `app/src/main/assets/original-engine.jar`。** Java 桥接在 Android 内部使用 `DexClassLoader` 加载原版 `com.chengfeng.duckassist.DuckClient`，直接调用原来的执行方法。无需重新猜造接口参数或复写刷蛋请求。

原版程序主要方法已静态核对：`probeHost / eggBalance / freeTimes / playable / init / state / moreTokens / report / farm`。`farm()` 中的实际请求、令牌、游戏状态及报告处理均由**用户上传的原版 DEX**执行。

### 原版功能及入口

| 功能 | 新版调用方式 | 状态 |
|---|---|---|
| 分片域名检测 | `DuckClient.probeHost(Log)` | 原版方法已连接 |
| 鸭蛋/鸭币余额 | `DuckClient.eggBalance()` | 原版方法已连接 |
| 免费局次、已看广告等状态 | `DuckClient.freeTimes()` | 原版方法已连接 |
| 是否可以开局 | `DuckClient.playable(Log)` | 原版方法已连接 |
| 抓鸭刷蛋、上报/令牌 | `DuckClient.farm(target, limit, rid, Log, Stop)` | **原版方法已连接**，内部继续使用原版 `init/state/moreTokens/report` |
| 开局失败后的 `roundId` 续接 | 从 `FarmResult.rid` 获取，按账号保存，下次重新传入 `farm` | 已实现 |
| 单账号日志/结果 | 原版 `Log` 回调，`FarmResult` 字段 | 已实现 |

### 账号管理新增

- 相册自定义头像，头像存在本机。
- 兼容 `备注 = 完整 CK` / `备注|完整 CK` / `完整 CK` 等批量导入；自动识别 `ud`；去重保留备注。
- 每个账号独立修改备注、CK 完整参数；独立保存 `roundId`。
- 账号本地加密存储：Android Keystore AES-256-GCM；最近版本及回退副本；加密数据与 Android App 包沙箱绑定。
- JSON 明文导入和导出备份（包含完整敏感 CK，千万不要公开分享）。
- 批量选择、全部账号，顺序或 2 并发，目标蛋数、上报上限、账号间隔；暂停/继续**账号队列**、停止任务；保存结果和日志。
- 任务页根据动作区分：刷蛋 / 余额 / 免费次数 / 开局检查 / 域名检查 / 状态查询。

## 交付验证与限制 — 请务必看清

1. **不是已编译 APK**：本容器没有 Android SDK、Gradle、设备和登录会话，不能在本地执行真实 Android APK 构建或联网实测。
2. **并非宣称原版接口仍然可用**：已经将原版字节码接到 Android 任务按钮，但服务端若改版、账号 CK 过期或网络不通，会返回原版实际错误。
3. `app/src/main/assets/index.html` 是 APK 内置 UI。直接打开提供的 `离线界面预览.html` 只是预览，不带 Android 原生桥接，不能运行真实接口。请不要再把预览网页当成 APK。
4. 原 APK 含有多个 `s1-hb1az*-idc-ppg.viviv.com` 游戏分片域名，以及 `nebula.kuaishou.com`，真实运行时会走原版的外部网络请求。账号凭证敏感，请仅导入自己的账号，并在确认目标接口属于你信任的服务后运行。
5. Android 原 APK 自身的 SharedPreferences 不会自动跨应用迁移到本工程包名中。第一次使用时要从你自己的记录中重新导入一次 CK，之后可以在 V3 中保存和备份。

## 生成 APK（建议 GitHub Actions）

1. 将项目 **整个根目录** 上传到你自己的私有 GitHub 仓库（包含 `app`、`settings.gradle`、`.github` 等文件）。**不要上传真实账号 CK、备份文件或日志。**
2. 在仓库 `Actions` 页找到 `Build LaoYa Duck V3 Android`，点 `Run workflow`。
3. 工作流使用 Android SDK 35、JDK 17、Gradle 8.10.2，构建命令：`gradle :app:assembleDebug --no-daemon --stacktrace`。
4. 若构建成功，从对应的 Artifacts 下载 `LaoYaDuckV3-original-engine-debug-APK`，解压获取 `app-debug.apk`。
5. 用自己的账号参数在 Android 真机检查域名、余额、局次、正常开局、停止与续接；任何网络错误以服务端响应为准。

也可用 Android Studio 打开根目录并 `Build > Build APK(s)`。

## 本地静态验收

- `node docs/test_parser.js`  → 账号批量导入/备注/去重/保存。
- `node docs/test_original_bridge.js` → 使用模拟回调测试双账号任务调度、原版方法派发、`roundId` 保存（**仅模拟，不连接接口**）。
- `javac` 使用本地轻量 Android stub 对 `OriginalDuckEngine.java` 做语法/类型校验通过，不等于 Android APK 编译成功。
- `docs/原版引擎校验.json` 包含输入 APK、原 DEX、封装引擎的 SHA-256 可复核指纹；JAR 内 `classes.dex` 和上传 APK 中的 `classes.dex` 字节完全相同。

这是原始 DEX **运行时复用**的迁移方案，不是对原 APK 原始签名的就地补丁。无需 Root。
